import numpy as np
import cv2
import sys

print(__doc__)

try:
    fn = sys.argv[1]
    if fn.isdigit() == True:
        fn = int(fn)
except:
    fn = 0
print(fn)

try:
    fps = sys.argv[2]
    fps = int(fps)
except:
    fps = 30
print (fps)

try:
    resize_rate = sys.argv[3]
    resize_rate = int(resize_rate)
except:
    resize_rate = 1
print (resize_rate)

video_input = cv2.VideoCapture(fn)
if (video_input.isOpened() == False):
    exit()

count = 0
while(True):
    count += 1

    ret, frame = video_input.read()

    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    #-30 to 0
    image_lower_hsv = np.array([160, 150, 10])
    image_upper_hsv = np.array([180, 255, 255])
    imageMask1 = cv2.inRange(hsv, image_lower_hsv, image_upper_hsv)
    #0 to 30
    image_lower_hsv = np.array([0, 150, 10])
    image_upper_hsv = np.array([20, 255, 255])
    imageMask2 = cv2.inRange(hsv, image_lower_hsv, image_upper_hsv)
    # combine masks
    finalMask = cv2.bitwise_or(imageMask1, imageMask2)

    img_color = cv2.bitwise_and(frame, frame, mask=finalMask)

    cv2.imshow('frame', finalMask)
    c = cv2.waitKey(int(1000/fps)) & 0xFF

    print(count)
    print("hello")
    write_file_name = ("photo{}.jpg".format(count))
    cv2.imwrite(write_file_name, finalMask)

    if c==27: # ESC
        break

video_input.release()
cv2.destroyAllWindows()